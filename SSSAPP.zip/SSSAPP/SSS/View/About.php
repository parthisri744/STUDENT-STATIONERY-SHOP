<div class="container-fluid text-center">
  <h2>University College Of Engineering Nagercoil</h2>
     <p>STUDENT STATIONERY SHOP</p>
         <div class="row">
            <div class="col-md-12 justify-content-center">
                <div class="card shadow">
                    <div class="card-body">
                    <img class="card-img-top" src="vendors/img/ucen.jpg" alt="Ucen image" style="width:100%; height: 500px">
                    <div class="card-body">
                    <h4 class="card-title"></h4>
                    <h4 class="card-text" style="padding-left:10px; font-family: 'Bitter', serif;">University College of Engineering,Nagercoil is one of the constituent Engineering Colleges of Anna University, Chennai. The campus is formed in the year 2009 with a goal of enhancing the quality of technical education in the southern part of Tamilnadu. It is a college for the top notch students. We provide under graduate courses with our highbrow and involved faculties. The institution also provides MBA in distance education mode. The students are admitted through single window counselling. Our vast campus with contemporary style buildings and smart classes provides world class experience and luxury for students to acquire knowledge. Trees and fresh air in the campus disentangles the entangles of the students and thus making it a wonderful study environment.</h4>
                    <a href="https://ucen.ac.in/about.php" class="btn btn-primary">See Official Website</a>
                </div>
            </div>
         </div>
     </div>
</div>