<?php
ini_set("display_errors",1);
ini_set("display_startup_errors",1);
error_reporting(E_ALL);
session_start();
 if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
spl_autoload_register(function($className) {
           require_once "../Model/".$className.".php";
});
$obj=new StuModel();
$userdata =$obj->student_details();
function decrypt($ivHashCiphertext, $password) {
    $method = "AES-256-CBC";
    $iv = substr($ivHashCiphertext, 0, 16);
    $hash = substr($ivHashCiphertext, 16, 32);
    $ciphertext = substr($ivHashCiphertext, 48);
    $key = hash('sha256', $password, true);
    if (!hash_equals(hash_hmac('sha256', $ciphertext . $iv, $key, true), $hash)) return null;
    return openssl_decrypt($ciphertext, $method, $key, OPENSSL_RAW_DATA, $iv);
  } 
$sname= $_SESSION['sname'];
$regno = $_SESSION['registerno'];
$submit = isset($_POST['confirm"']);
if($submit){
    $result = $obj->purchasedata($sname,$regno,$submit);
    var_dump($result);
}
// 
// if($result > 0){
// }else{

// }
//var_dump($result);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head> 
<title>SSS</title>
<body>
<div><?php  require_once("../Navigation/stuNavigation.php");  ?></div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card shadow">
                    <div class="card-body">       
                    <div class="text-center">
                        <h3>University College Of Engineering Nagercoil</h3>
                        <h4>STUDENT STATIONERY SHOP</h4>
                        </div>
                       <div class="col-md-10 align-item-center mx-auto">
                    <div class="card shadow">
                    <div class="card-body bg-light">      
                    <div class="text-center">
                    <img src="../vendors/img/student-graduate.jpg " alt="Anna University Logo" >
                        <h3>Student Details</h3>
                     </div>
                     <div class="col-md-5 align-item-center mx-auto ">
                     <table class="table table-sm" >
                    <tbody>
                    <?php if(!empty($userdata)) { ?>
                        <?php  foreach($userdata as $studata){  ?>
                        <tr class="text-center">
                        <td>Student Name</td>
                        <td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</td>
                        <td><?php echo $_SESSION['sname']  ?></td>
                        </tr>
                        <tr class="text-center">
                        <td>Register Number</td>
                        <td>&nbsp&nbsp&nbsp</td>
                        <td><?php echo $_SESSION['registerno']  ?></td>
                        </tr>
                        <tr class="text-center">
                        <td>Course</td>
                        <td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</td>
                        <td><?php echo decrypt(base64_decode( $studata['course']),"UcEnSsS"); ?></td>
                        </tr>
                        <tr class="text-center">
                        <td>Course</td>
                        <td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</td>
                        <td><?php echo $studata['branch'] ?></td>
                        </tr>
                        <tr class="text-center">
                        <td>Date of Birth</td>
                        <td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</td>
                        <td><?php echo $studata['dob']  ?></td>
                        </tr>
                        <tr class="text-center">
                        <td>Email ID</td>
                        <td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</td>
                        <td><?php echo $studata['email']  ?></td>
                        </tr>
                        <?php  } } ?>
                    </tbody >
                    </table>
                    </div>
                    <div class="text-center">
                    <input type="submit" name="confirm" id="confirm" class="btn btn-primary" value="confirm">  <a href="../stuindex.php?temp=10a6ffc60e5f71be379d70dc20faefc5" class="btn btn-danger" >Cancel</a>
                    </div>
                   </div>             
              </div>
          </div><br/><br/><br/>
         </div>
       </div>
    </div>            
   </div>
  </div>
 </div>
 <script>
$('#confirm').on("click", function(){  
           console.log("comfirm clicked");
           var sname = "<?php echo $_SESSION['sname']  ?>";
           var regno = "<?php echo $_SESSION['registerno']  ?>";
           $.ajax({  
                     url:"../Model/Ajaxinsert.php?functionname=purchasedata&id=0",
                     method:"POST",  
                     data:{sname : sname,regno :regno},   
                     success:function(data){ 
                         if(data == "Invalid Input"){
                            setTimeout(function() {
                            swal('Success',data,"success");
                             }, 1000);
                         }else{
                            setTimeout(function() {
                            swal('Success','Success',"success");
                             }, 1000);
                             window.location = "Purchase.php?purchaseid="+data;                      }

                    //     if(data == "Inserted Successsfully" || data== "Updated Successfully" ){
                    //     setTimeout(function() {
                    //     swal('Success',data,"success");
                    //      }, 1000);
                    //  } 
                     } 
                });  
           }); 
</script>
<script src="../vendors/js/Main.js"></script>
<link rel='stylesheet' href='../vendors/css/style.css'></link>  
</body>
<br /></br/> 
<div class="footer fixed-bottom bg-primary   ">
<div class="footer-copyright text-center py-3">© 2021 Copyright:UCEN
</div>
</div>
</html>
<!--sticky-buttom page-footer -->   
<!-- Purchase.php -->