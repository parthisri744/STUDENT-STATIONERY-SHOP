-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Sep 03, 2021 at 04:29 PM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `SSS`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminstock`
--

CREATE TABLE `adminstock` (
  `ID` int(11) NOT NULL,
  `product_name` varchar(255) DEFAULT NULL,
  `product_quantity` varchar(25) DEFAULT NULL,
  `product_price` varchar(25) DEFAULT NULL,
  `last_updated_time` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `adminstock`
--

INSERT INTO `adminstock` (`ID`, `product_name`, `product_quantity`, `product_price`, `last_updated_time`) VALUES
(47, 'pen', '78', '65', '2021-08-09 18:04:08'),
(48, 'pencil', '556', '5', '2021-08-10 02:10:00');

-- --------------------------------------------------------

--
-- Table structure for table `puchase_list`
--

CREATE TABLE `puchase_list` (
  `ID` int(11) NOT NULL,
  `purchaseno` int(11) DEFAULT NULL,
  `product_name` varchar(255) DEFAULT NULL,
  `product_quantity` int(11) DEFAULT NULL,
  `pencil` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `puchase_list`
--

INSERT INTO `puchase_list` (`ID`, `purchaseno`, `product_name`, `product_quantity`, `pencil`) VALUES
(1, 1, 'pen', 587, NULL),
(2, 1, 'pen', 9854, NULL),
(3, 1, 'pen', 8754, NULL),
(4, 2, 'pen', 85, NULL),
(5, 3, 'pen', 8456, NULL),
(6, 4, 'pen', 545878787, NULL),
(7, 4, 'pen', 877877, NULL),
(8, 4, 'pen', 877877, NULL),
(9, 5, 'pen', 12548, NULL),
(10, 5, 'pen', 687987, NULL),
(11, 6, 'pen', 54458755, NULL),
(12, 6, 'pen', 54458755, NULL),
(13, 6, 'pen', 54458755, NULL),
(14, 6, 'pen', 54458755, NULL),
(15, 6, 'pen', 54458755, NULL),
(16, 6, 'pen', 54458755, NULL),
(17, 6, 'pen', 54458755, NULL),
(18, 6, 'pen', 54458755, NULL),
(19, 6, 'pen', 54458755, NULL),
(20, 6, 'pen', 54458755, NULL),
(21, 7, 'pen', 12548, NULL),
(22, 8, 'pen', 35235, NULL),
(23, 9, 'pen', 4, NULL),
(24, 10, 'pen', 5, NULL),
(25, 10, 'pen', 5, NULL),
(26, 11, 'pencil', 4, NULL),
(27, 12, 'pencil', 10, NULL),
(28, 12, 'pen', 20, NULL),
(29, 13, 'pen', 55, NULL),
(30, 13, 'pencil', 955, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `purchase`
--

CREATE TABLE `purchase` (
  `ID` int(11) NOT NULL,
  `Stu_name` varchar(255) NOT NULL,
  `stu_regno` varchar(25) NOT NULL,
  `status` varchar(25) DEFAULT NULL,
  `sbmitted_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `purchase`
--

INSERT INTO `purchase` (`ID`, `Stu_name`, `stu_regno`, `status`, `sbmitted_time`) VALUES
(1, 'parthiban', '5134', 'Save Draft', '2021-08-09 22:05:59'),
(2, 'parthiban', '5134', 'Save Draft', '2021-08-09 22:10:31'),
(3, 'parthiban', '5134', 'Save Draft', '2021-08-09 22:12:17'),
(4, 'parthiban', '5134', 'Save Draft', '2021-08-09 22:13:23'),
(5, 'parthiban', '5134', 'Save Draft', '2021-08-09 22:14:38'),
(6, 'parthiban', '5134', 'Save Draft', '2021-08-09 22:29:46'),
(7, 'parthiban', '5134', 'Save Draft', '2021-08-09 22:31:40'),
(8, 'parthiban', '5134', 'Save Draft', '2021-08-10 01:18:34'),
(9, 'rammorthy', '5134', 'Save Draft', '2021-08-10 02:04:24'),
(13, 'd.jayasurya', '202115053', 'Save Draft', '2021-08-20 11:35:16');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `ID` int(11) NOT NULL,
  `regno` varchar(255) DEFAULT NULL,
  `sname` varchar(255) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `course` varchar(255) DEFAULT NULL,
  `branch` varchar(255) DEFAULT NULL,
  `syear` varchar(255) DEFAULT NULL,
  `balance` int(11) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `stu_address` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `submitted_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `passflag` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`ID`, `regno`, `sname`, `dob`, `course`, `branch`, `syear`, `balance`, `phoneno`, `stu_address`, `email`, `password`, `submitted_time`, `passflag`) VALUES
(16, '202115053', 'd.jayasurya', '2021-05-20', '11hmCQOqfqL/Gr4Adi5OBs3CrIzObz1qfMLXe6V9NnSy9eOu90k/wR/M81GCWJYac8NslLy1/F3NZ0TmL5j32FEZwCyaCE8waMuCeFeZCA8=', 'Mechanical Engineering', 'First Year', 1000, '0123645758', 'IGCAR, Kalpakkam', 'test@igcar.gov.in', '$2y$10$y2cJcBXkG4twBobGkX0EheWJj2rD.vefhe..yJT.JqvI3RfnKadFe', '2021-08-20 11:34:26', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `created_at`) VALUES
(1, 'riya24', '$2y$10$XlDpAmQOzShsXXcCXb093uMG77/Wt/.mAFbVIfuoYcdGr.UEKtOKe', '2021-08-08 21:22:23'),
(2, 'parthisri', '$2y$10$759WXTGfJ4JQa5lYzf337.UAaNeGX09XEbmmYG4vpwUlqfNdGH9Uu', '2021-08-08 21:27:06'),
(3, 'admin', '$2y$10$.MQrPDdSa3Q1TTLW99EpRuu6WS4JeUtUhGHseZZ6Gzrywk6gcnWlS', '2021-08-10 08:40:55'),
(4, 'riya', '$2y$10$eg8AvfThtCh7PCXIrac90egBF4IBpGV4aDwVozIcTaO7wmPvA39B6', '2021-08-10 09:21:47'),
(5, 'praveen', '$2y$10$4mdSyQXew5dnMbZ4uUra4O2pkFSNZPH0wS/6h1oVM3eBPknXz89iS', '2021-08-10 09:22:33'),
(6, 'parthiban', '$2y$10$vi812dkT85aZZ9ut3rXW3eu2WyKgRKYvVBnUtWMkHqksgWZ7VgNki', '2021-08-14 08:45:44');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adminstock`
--
ALTER TABLE `adminstock`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `puchase_list`
--
ALTER TABLE `puchase_list`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `purchase`
--
ALTER TABLE `purchase`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adminstock`
--
ALTER TABLE `adminstock`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `puchase_list`
--
ALTER TABLE `puchase_list`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `purchase`
--
ALTER TABLE `purchase`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
